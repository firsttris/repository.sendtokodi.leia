# flake8: noqa: F401

# ℹ️ The imported name must end in "PP" and is the name to be used in --use-postprocessor
from .sample import SamplePluginPP
